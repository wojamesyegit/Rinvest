
print ("Content-type: text/html\n\n")
print ("Hello, world!\n")